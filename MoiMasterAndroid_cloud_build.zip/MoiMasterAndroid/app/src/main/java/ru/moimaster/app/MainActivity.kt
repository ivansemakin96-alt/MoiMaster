package ru.moimaster.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "services")
data class ServiceEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val price: Double, val note: String = "")
@Entity(tableName = "orders")
data class OrderEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val client: String, val phone: String, val address: String, val date: Long, val revenue: Double, val expense: Double, val paid: Double, val note: String = "")
@Entity(tableName = "expenses")
data class ExpenseEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val amount: Double, val date: Long, val note: String = "")
@Entity(tableName = "clients")
data class ClientEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val phone: String, val note: String = "")

@Dao
interface AppDao {
    @Query("SELECT * FROM services ORDER BY title") fun services(): kotlinx.coroutines.flow.Flow<List<ServiceEntity>>
    @Insert suspend fun addService(x: ServiceEntity)
    @Delete suspend fun deleteService(x: ServiceEntity)
    @Query("SELECT * FROM orders ORDER BY date DESC") fun orders(): kotlinx.coroutines.flow.Flow<List<OrderEntity>>
    @Insert suspend fun addOrder(x: OrderEntity)
    @Delete suspend fun deleteOrder(x: OrderEntity)
    @Query("SELECT * FROM expenses ORDER BY date DESC") fun expenses(): kotlinx.coroutines.flow.Flow<List<ExpenseEntity>>
    @Insert suspend fun addExpense(x: ExpenseEntity)
    @Delete suspend fun deleteExpense(x: ExpenseEntity)
    @Query("SELECT * FROM clients ORDER BY name") fun clients(): kotlinx.coroutines.flow.Flow<List<ClientEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveClient(x: ClientEntity)
    @Delete suspend fun deleteClient(x: ClientEntity)
}
@Database(entities = [ServiceEntity::class, OrderEntity::class, ExpenseEntity::class, ClientEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var INSTANCE: AppDb? = null
        fun get(c: Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "moi_master.db").build().also { INSTANCE = it }
        }
    }
}

private val bg = Color(0xFF101318)
private val panel = Color(0xFF1B2028)
private val orange = Color(0xFFFF9D35)
private val green = Color(0xFF63C58A)
private fun money(v: Double) = "%,.0f ₽".format(Locale("ru", "RU"), v)
private fun date(v: Long) = SimpleDateFormat("dd.MM.yyyy", Locale("ru")).format(Date(v))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDb.get(this).dao()
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = orange, background = bg, surface = panel)) { MainScreen(dao) } }
    }
}

@Composable
fun MainScreen(dao: AppDao) {
    val scope = rememberCoroutineScope()
    val orders by dao.orders().collectAsState(initial = emptyList())
    val services by dao.services().collectAsState(initial = emptyList())
    val expenses by dao.expenses().collectAsState(initial = emptyList())
    val clients by dao.clients().collectAsState(initial = emptyList())
    var tab by remember { mutableStateOf("Главная") }
    var dialog by remember { mutableStateOf("") }
    var selectedOrder by remember { mutableStateOf<OrderEntity?>(null) }
    val total = orders.sumOf { it.revenue }
    val costs = orders.sumOf { it.expense } + expenses.sumOf { it.amount }
    val net = total - costs
    val debt = orders.sumOf { (it.revenue - it.paid).coerceAtLeast(0.0) }

    Scaffold(containerColor = bg, bottomBar = {
        NavigationBar(containerColor = panel) {
            listOf("Главная", "Заказы", "Услуги", "Расходы", "Клиенты").forEach { item ->
                NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = {
                    Icon(when(item) { "Главная" -> Icons.Default.Home; "Заказы" -> Icons.Default.ReceiptLong; "Услуги" -> Icons.Default.Handyman; "Расходы" -> Icons.Default.Payments; else -> Icons.Default.People }, null)
                }, label = { Text(item) })
            }
        }
    }, floatingActionButton = {
        if (tab != "Главная") FloatingActionButton(onClick = { dialog = when(tab) { "Заказы" -> "order"; "Услуги" -> "service"; "Расходы" -> "expense"; "Клиенты" -> "client"; else -> "" } }, containerColor = orange, contentColor = Color.Black) { Icon(Icons.Default.Add, "Добавить") }
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Text("МОЙ МАСТЕР", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = Color.White)
            Text("Личный учёт работы и заработка", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            when(tab) {
                "Главная" -> {
                    Text("Финансы", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("Выручка", money(total), Modifier.weight(1f))
                        StatCard("Чистыми", money(net), Modifier.weight(1f), green)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("Расходы", money(costs), Modifier.weight(1f), orange)
                        StatCard("Долги", money(debt), Modifier.weight(1f), Color(0xFFFF7777))
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { dialog = "order" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = orange, contentColor = Color.Black)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Добавить заказ") }
                    OutlinedButton(onClick = { dialog = "expense"; tab = "Расходы" }, modifier = Modifier.fillMaxWidth()) { Text("Записать расход") }
                    Text("Последние заказы", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
                    LazyColumn { items(orders.take(5)) { OrderRow(it, { selectedOrder = it; dialog = "details" }, { scope.launch { dao.deleteOrder(it) } }) } }
                }
                "Заказы" -> {
                    Text("Все заказы (${orders.size})", color = Color.White, fontWeight = FontWeight.Bold)
                    LazyColumn { items(orders) { OrderRow(it, { selectedOrder = it; dialog = "details" }, { scope.launch { dao.deleteOrder(it) } }) } }
                }
                "Услуги" -> {
                    Text("Мои услуги и цены", color = Color.White, fontWeight = FontWeight.Bold)
                    LazyColumn { items(services) { s ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(s.title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(money(s.price), color = orange) }
                                IconButton(onClick = { scope.launch { dao.deleteService(s) } }) { Icon(Icons.Default.Delete, null, tint = Color.LightGray) }
                            }
                        }
                    } }
                }
                "Расходы" -> {
                    Text("Дополнительные расходы", color = Color.White, fontWeight = FontWeight.Bold)
                    LazyColumn { items(expenses) { e ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(e.title, color = Color.White); Text("${money(e.amount)} · ${date(e.date)}", color = orange) }
                                IconButton(onClick = { scope.launch { dao.deleteExpense(e) } }) { Icon(Icons.Default.Delete, null, tint = Color.LightGray) }
                            }
                        }
                    } }
                }
                "Клиенты" -> {
                    Text("Клиенты (${clients.size})", color = Color.White, fontWeight = FontWeight.Bold)
                    LazyColumn { items(clients) { c ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(c.name, color = Color.White); Text(c.phone, color = Color.LightGray) }
                                IconButton(onClick = { scope.launch { dao.deleteClient(c) } }) { Icon(Icons.Default.Delete, null, tint = Color.LightGray) }
                            }
                        }
                    } }
                }
            }
        }
    }

    if (dialog == "service") EntryDialog("Новая услуга", listOf("Название услуги", "Цена, ₽", "Описание"), { v ->
        scope.launch { dao.addService(ServiceEntity(title=v[0], price=v[1].toDoubleOrNull() ?: 0.0, note=v[2])) }; dialog=""
    }) { dialog="" }
    if (dialog == "expense") EntryDialog("Новый расход", listOf("На что потрачено", "Сумма, ₽", "Комментарий"), { v ->
        scope.launch { dao.addExpense(ExpenseEntity(title=v[0], amount=v[1].toDoubleOrNull() ?: 0.0, date=System.currentTimeMillis(), note=v[2])) }; dialog=""
    }) { dialog="" }
    if (dialog == "client") EntryDialog("Новый клиент", listOf("Имя клиента", "Телефон", "Заметка"), { v ->
        scope.launch { dao.saveClient(ClientEntity(name=v[0], phone=v[1], note=v[2])) }; dialog=""
    }) { dialog="" }
    if (dialog == "order") {
        val fields = listOf("Услуга / работа", "Имя клиента", "Телефон", "Адрес", "Стоимость заказа, ₽", "Расходы по заказу, ₽", "Получено от клиента, ₽", "Комментарий")
        EntryDialog("Новый заказ", fields, { v ->
            val revenue = v[4].toDoubleOrNull() ?: 0.0
            val expense = v[5].toDoubleOrNull() ?: 0.0
            scope.launch {
                dao.addOrder(OrderEntity(title=v[0], client=v[1], phone=v[2], address=v[3], date=System.currentTimeMillis(), revenue=revenue, expense=expense, paid=v[6].toDoubleOrNull() ?: revenue, note=v[7]))
                if (v[1].isNotBlank()) dao.saveClient(ClientEntity(name=v[1], phone=v[2]))
            }; dialog=""
        }) { dialog="" }
    }
    if (dialog == "details" && selectedOrder != null) {
        val o = selectedOrder!!
        AlertDialog(onDismissRequest={dialog=""}, containerColor=panel, title={Text(o.title, color=Color.White)}, text={
            Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                Text("Дата: ${date(o.date)}", color=Color.LightGray)
                Text("Клиент: ${o.client}", color=Color.White)
                Text("Телефон: ${o.phone}", color=Color.White)
                Text("Адрес: ${o.address}", color=Color.White)
                Text("Стоимость: ${money(o.revenue)}", color=Color.White)
                Text("Расходы: ${money(o.expense)}", color=Color.White)
                Text("Получено: ${money(o.paid)}", color=Color.White)
                Text("Чистыми по заказу: ${money(o.revenue-o.expense)}", color=green)
                Text("Долг: ${money((o.revenue-o.paid).coerceAtLeast(0.0))}", color=orange)
                if(o.note.isNotBlank()) Text(o.note, color=Color.LightGray)
            }
        }, confirmButton={TextButton(onClick={dialog=""}) {Text("Закрыть")}})
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    Card(modifier.padding(vertical=4.dp), colors=CardDefaults.cardColors(containerColor=panel), shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) { Text(label, color=Color.LightGray, style=MaterialTheme.typography.labelMedium); Spacer(Modifier.height(5.dp)); Text(value, color=valueColor, fontWeight=FontWeight.Bold, style=MaterialTheme.typography.titleMedium) }
    }
}
@Composable
fun OrderRow(o: OrderEntity, open: () -> Unit, delete: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable { open() }, colors=CardDefaults.cardColors(containerColor=panel)) {
        Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(o.title, color=Color.White, fontWeight=FontWeight.SemiBold)
                Text("${o.client.ifBlank { "Без имени" }} · ${date(o.date)}", color=Color.LightGray, style=MaterialTheme.typography.bodySmall)
                Text("Чистыми: ${money(o.revenue-o.expense)}", color=green, style=MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment=Alignment.End) {
                Text(money(o.revenue), color=orange, fontWeight=FontWeight.Bold)
                IconButton(onClick=delete) { Icon(Icons.Default.Delete, null, tint=Color.LightGray) }
            }
        }
    }
}
@Composable
fun EntryDialog(title: String, labels: List<String>, save: (List<String>) -> Unit, close: () -> Unit) {
    val values = remember(title) { mutableStateListOf<String>().apply { repeat(labels.size) { add("") } } }
    AlertDialog(onDismissRequest=close, containerColor=panel, title={Text(title, color=Color.White)}, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.heightIn(max=440.dp)) {
            labels.forEachIndexed { i, label ->
                OutlinedTextField(value=values[i], onValueChange={values[i]=it}, label={Text(label)}, modifier=Modifier.fillMaxWidth(), singleLine=true, keyboardOptions=if(label.contains("₽")) KeyboardOptions(keyboardType=KeyboardType.Decimal) else KeyboardOptions.Default)
            }
        }
    }, confirmButton={ TextButton(onClick={save(values.toList())}) {Text("Сохранить", color=orange)} }, dismissButton={TextButton(onClick=close){Text("Отмена")}})
}
